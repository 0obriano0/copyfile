#include <iostream>
#include <windows.h>
#define MOD_NOREPEAT 0x4000
#define MOD_CONTROL 0x0002
#define MOD_ALT 0x0001
using namespace std;
 

int main()
{
 	int a=0,b=0,c=0,d=0,e=0,f=0;
    MSG msg = { 0 };
    HWND hConsole = GetActiveWindow();
    //Ctrl + A
    RegisterHotKey(hConsole,1,MOD_CONTROL|MOD_NOREPEAT,'A'); 
    //Ctrl+B
    RegisterHotKey(hConsole, 2, MOD_CONTROL | MOD_NOREPEAT, 'B');
    //ALT+A
    RegisterHotKey(hConsole, 3, MOD_ALT | MOD_NOREPEAT, 'A');
    //ALT+B
    RegisterHotKey(hConsole, 4, MOD_ALT | MOD_NOREPEAT, 'B');
    //������S
    RegisterHotKey(hConsole, 5, MOD_NOREPEAT, 'S');
    //������PageDown 
    RegisterHotKey(hConsole,6,MOD_NOREPEAT,0X22);

    while (GetMessage(&msg, NULL, 0, 0) != 0)
    {
        if (msg.message == WM_HOTKEY)
        {
            switch (msg.wParam)
            {
            case 1:      	
				a++;
                printf("�A�w���UCtrl+A���%d��\n",a); break;
            case 2:
            
				b++;
                printf("�A�w���UCtrl+B���%d��\n",b); break;
            case 3:
           
				c++;
                printf("�A�w���UALT+A���%d��\n",c); break;
            case 4:
            
            	d++;
                printf("�A�w���UALT+B���%d��\n",d); break;
            case 5:
      
            	e++;
                printf("�A�w���US���%d��\n",e); break;
			case 6:
        
            	f++;
                printf("�A�w���UPage Down���%d��\n",f); break; 
            default:
                break;
            }

        }
    }
    return 0;
}
